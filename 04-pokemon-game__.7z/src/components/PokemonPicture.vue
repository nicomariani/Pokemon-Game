<template>

    <div class="pokemon-container">
        <img    v-bind:src= "imgSrc"
                class="hidden-pokemon"
                alt="pokemon">

      
        <img  v-if="showPokemon"  v-bind:src= "imgSrc"
                class="fade-in"
                alt="pokemon">
                     
    </div>

</template>

<script>

export default {

    props:{
            pokemonId: {
                type: Number,
                required: true
            },
            showPokemon:{
                type: Boolean,
                required: true,
                default: false
            }

    },
    computed:{
        imgSrc(){
           return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/${this.pokemonId}.svg`
        }
    }

}
</script>

<!--El Scoped es para que el stylo solo aplique para este componente y no a nivel global-->
<style scoped>
    .pokemon-container {
        height: 200px;
    }
    img {
    height: 200px;
    position: absolute;
    left: 0;
    right: 0;
    margin: 0 auto;
    user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -webkit-user-drag: none;
    -webkit-user-select: none;
}
    .hidden-pokemon {
        filter: brightness(0);
    }
</style>