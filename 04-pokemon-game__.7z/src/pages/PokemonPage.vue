<template>
  <h1 v-if="!pokemon">Espere por favor ...</h1>
  <div v-else>
    <h1>Quien es este Pokemon?</h1>

    <PokemonPicture  v-bind:pokemonId="pokemon.id" v-bind:showPokemon="showPokemon"  />
    <!--<PokemonPicture  :pokemonId=4 :showPokemon=true  />-->
    <PokemonOptions v-bind:pokemons="pokemonArr" @selection="checkAnswer($event)"/>
    
    <!-- Si solo se recibe un argurmento se puede obviar pasarlo como parametro, 
     <PokemonOptions v-bind:pokemons="pokemonArr" @selection="checkAnswer"/>
    -->


    <!--En lugar de un div agrupador, se puede usar el tag template-->
    <template v-if="showAnswer">
      <h2>{{ message }}</h2>
      <button @click="newGame">Nuevo Juego</button>
    </template>

  </div>
</template>

<script>
    import PokemonOptions from '@/components/PokemonOptions'
    import PokemonPicture from '@/components/PokemonPicture'
    import getPokemonsOptions from '@/helpers/getPokemonOptions'


    export default {
        components: { PokemonOptions,PokemonPicture },
        data()  {
          return {
                  pokemonArr:[],
                  pokemon: null,
                  showPokemon: false,
                  showAnswer: false,
                  message: ''
                }
          },
        methods:  { 
          async mixPokemonArray(){

            this.pokemonArr = await getPokemonsOptions()                  
            const rndInt = Math.floor(Math.random() * 4 )
            this.pokemon = this.pokemonArr[rndInt]

          },
            checkAnswer(pokemonId){
              if (this.pokemon.id === pokemonId) {
                this.showPokemon = true
                this.message = `Correcto!, ${this.pokemon.name}`
                              
              }
              else {
                this.message = `Upss Opcion Incorrecta!! Era ${this.pokemon.name}`
              }

              this.showAnswer = true
            },
            newGame(){
              this.pokemon = null
              this.pokemonArr = []
              this.showAnswer = false
              this.showPokemon = false
              this.mixPokemonArray()

            }
         },
         mounted(){
          this.mixPokemonArray()
          
         }    

    }
</script>

